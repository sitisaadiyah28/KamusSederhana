<?php

$connect= new mysqli("localhost", "root", "", "db_kamus");
if($connect){

} else {
	echo "Koneksi gagal";
	exit();
}


?>